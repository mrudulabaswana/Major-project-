import React from "react";
import { Star } from "lucide-react";
import { cn } from "@/lib/utils";

interface StarRatingProps {
  value: number;
  onChange?: (value: number) => void;
  disabled?: boolean;
}

export function StarRating({ value, onChange, disabled }: StarRatingProps) {
  return (
    <div className="flex items-center gap-1" data-testid="input-rating">
      {[1, 2, 3, 4, 5].map((star) => (
        <button
          key={star}
          type="button"
          disabled={disabled}
          className={cn(
            "focus:outline-none transition-colors",
            disabled ? "cursor-not-allowed opacity-50" : "cursor-pointer hover:scale-110",
            value >= star ? "text-amber-500" : "text-muted"
          )}
          onClick={() => onChange?.(star)}
        >
          <Star className="w-6 h-6" fill={value >= star ? "currentColor" : "none"} />
        </button>
      ))}
    </div>
  );
}
