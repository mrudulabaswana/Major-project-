import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { useCreateFeedback } from "@workspace/api-client-react";
import { useToast } from "@/hooks/use-toast";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { StarRating } from "@/components/ui/star-rating";
import {
  BookOpen,
  Presentation,
  Users,
  FlaskConical,
  FileText,
  Building2,
  CheckCircle,
  ArrowRight,
  GraduationCap,
} from "lucide-react";

const CATEGORY_DATA = {
  faculty_feedback: {
    label: "Faculty Feedback",
    desc: "Evaluate the effectiveness of teaching and faculty performance",
    icon: Users,
    reasons: [
      "Subject knowledge",
      "Teaching methodology",
      "Communication skills",
      "Doubt clarification",
      "Punctuality and discipline",
    ],
  },
  course_subject_feedback: {
    label: "Course / Subject Feedback",
    desc: "Feedback on syllabus, relevance, and study materials",
    icon: BookOpen,
    reasons: [
      "Syllabus relevance",
      "Course difficulty level",
      "Practical applicability",
      "Availability of study materials",
      "Assignment usefulness",
    ],
  },
  classroom_environment: {
    label: "Classroom Environment",
    desc: "Improve the overall classroom learning environment",
    icon: Presentation,
    reasons: [
      "Classroom cleanliness",
      "Seating arrangements",
      "Lighting and ventilation",
      "Audio/visual equipment availability",
      "Noise-free environment",
    ],
  },
  laboratory: {
    label: "Laboratory",
    desc: "Ensure effective practical learning experiences",
    icon: FlaskConical,
    reasons: [
      "Availability of equipment",
      "System or equipment condition",
      "Internet/software availability",
      "Lab maintenance",
      "Lab staff support",
    ],
  },
  examination_assessment: {
    label: "Examination & Assessment",
    desc: "Improve fairness and effectiveness of evaluation",
    icon: FileText,
    reasons: [
      "Exam difficulty level",
      "Transparency of evaluation",
      "Internal assessment process",
      "Assignment evaluation",
      "Timely result publication",
    ],
  },
  infrastructure_facilities: {
    label: "Infrastructure & Facilities",
    desc: "Enhance campus facilities and student satisfaction",
    icon: Building2,
    reasons: [
      "Library facilities",
      "Wi-Fi connectivity",
      "Drinking water facilities",
      "Washroom cleanliness",
      "Campus maintenance",
    ],
  },
} as const;

type CategoryType = keyof typeof CATEGORY_DATA;

const formSchema = z.object({
  name: z.string().min(2, "Name is required"),
  studentId: z.string().min(1, "Student ID is required"),
  email: z.string().email("Invalid email address"),
  phone: z.string().optional(),
  category: z.enum([
    "faculty_feedback",
    "course_subject_feedback",
    "classroom_environment",
    "laboratory",
    "examination_assessment",
    "infrastructure_facilities",
  ]),
  subReason: z.string().min(1, "Please select a specific reason"),
  rating: z.number().min(1, "Please provide a rating").max(5),
  message: z.string().min(10, "Message must be at least 10 characters"),
});

type FormValues = z.infer<typeof formSchema>;

export default function Home() {
  const { toast } = useToast();
  const createFeedback = useCreateFeedback();
  const [submittedName, setSubmittedName] = useState<string | null>(null);

  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: "",
      studentId: "",
      email: "",
      phone: "",
      rating: 0,
      category: "faculty_feedback",
      subReason: "",
      message: "",
    },
  });

  const selectedCategory = form.watch("category") as CategoryType;

  const onSubmit = (data: FormValues) => {
    createFeedback.mutate(
      { data: { ...data, department: "", semester: "" } },
      {
        onSuccess: () => {
          setSubmittedName(data.name);
          form.reset();
        },
        onError: () => {
          toast({
            title: "Submission Failed",
            description: "Failed to submit request. Please try again.",
            variant: "destructive",
          });
        },
      }
    );
  };

  if (submittedName) {
    return (
      <div
        className="min-h-[calc(100vh-3.5rem)] flex items-center justify-center p-4"
        style={{
          backgroundImage:
            "url('https://images.unsplash.com/photo-1541339907198-e08756dedf3f?w=1600&q=80&fit=crop')",
          backgroundSize: "cover",
          backgroundPosition: "center",
        }}
      >
        <div className="absolute inset-0 bg-indigo-950/60 backdrop-blur-sm" style={{ top: "3.5rem" }} />
        <Card className="relative z-10 max-w-md w-full shadow-2xl border-0">
          <CardContent className="pt-10 pb-8 px-8 text-center space-y-5">
            <div className="mx-auto w-16 h-16 bg-green-100 rounded-full flex items-center justify-center">
              <CheckCircle className="w-9 h-9 text-green-600" />
            </div>
            <div>
              <h2 className="text-2xl font-bold text-foreground">Thank you, {submittedName}!</h2>
              <p className="text-muted-foreground mt-2 text-sm leading-relaxed">
                Your request has been submitted and forwarded to the administration. We will review it shortly.
              </p>
            </div>
            <Button className="w-full" onClick={() => setSubmittedName(null)}>
              Submit Another Request
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div
      className="relative min-h-[calc(100vh-3.5rem)]"
      style={{
        backgroundImage:
          "url('https://images.unsplash.com/photo-1541339907198-e08756dedf3f?w=1600&q=80&fit=crop')",
        backgroundSize: "cover",
        backgroundPosition: "center",
        backgroundAttachment: "fixed",
      }}
    >
      {/* Dark overlay */}
      <div className="absolute inset-0 bg-indigo-950/65" />

      <div className="relative z-10 py-12 px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-10">
          <div className="inline-flex items-center justify-center w-14 h-14 rounded-2xl bg-white/10 backdrop-blur border border-white/20 mb-4">
            <GraduationCap className="w-7 h-7 text-white" />
          </div>
          <h1 className="text-4xl font-bold text-white tracking-tight drop-shadow">
            Submit Feedback or Request
          </h1>
          <p className="text-indigo-200 mt-2 text-lg">
            Your voice helps us improve our institution's environment and services.
          </p>
        </div>

        <div className="max-w-2xl mx-auto">
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              {/* Student Details */}
              <Card className="shadow-xl border-0 bg-white/95 backdrop-blur">
                <CardHeader className="border-b pb-4">
                  <CardTitle className="text-lg text-primary">Student Details</CardTitle>
                  <CardDescription>Your personal information</CardDescription>
                </CardHeader>
                <CardContent className="pt-6 grid grid-cols-1 md:grid-cols-2 gap-5">
                  <FormField
                    control={form.control}
                    name="name"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Full Name *</FormLabel>
                        <FormControl>
                          <Input placeholder="John Doe" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="studentId"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Student ID / Roll Number *</FormLabel>
                        <FormControl>
                          <Input placeholder="e.g. CS2023001" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="email"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Email Address *</FormLabel>
                        <FormControl>
                          <Input type="email" placeholder="john.doe@university.edu" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="phone"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Phone Number (Optional)</FormLabel>
                        <FormControl>
                          <Input type="tel" placeholder="+91 98765 43210" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </CardContent>
              </Card>

              {/* Feedback Details */}
              <Card className="shadow-xl border-0 bg-white/95 backdrop-blur">
                <CardHeader className="border-b pb-4">
                  <CardTitle className="text-lg text-primary">Feedback Details</CardTitle>
                  <CardDescription>What would you like to share with us?</CardDescription>
                </CardHeader>
                <CardContent className="pt-6 space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                    <FormField
                      control={form.control}
                      name="category"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Category *</FormLabel>
                          <Select
                            onValueChange={(val) => {
                              field.onChange(val);
                              form.setValue("subReason", "");
                            }}
                            defaultValue={field.value}
                          >
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Select a category" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              {Object.entries(CATEGORY_DATA).map(([key, data]) => {
                                const Icon = data.icon;
                                return (
                                  <SelectItem key={key} value={key} className="py-2.5">
                                    <div className="flex items-center gap-2">
                                      <Icon className="w-4 h-4 text-primary shrink-0" />
                                      <span>{data.label}</span>
                                    </div>
                                  </SelectItem>
                                );
                              })}
                            </SelectContent>
                          </Select>
                          {selectedCategory && (
                            <p className="text-xs text-muted-foreground mt-1.5">
                              {CATEGORY_DATA[selectedCategory].desc}
                            </p>
                          )}
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="subReason"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Specific Reason *</FormLabel>
                          <Select
                            onValueChange={field.onChange}
                            value={field.value}
                            disabled={!selectedCategory}
                          >
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Select specific reason" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              {selectedCategory &&
                                CATEGORY_DATA[selectedCategory].reasons.map((reason) => (
                                  <SelectItem key={reason} value={reason}>
                                    {reason}
                                  </SelectItem>
                                ))}
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <FormField
                    control={form.control}
                    name="rating"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Overall Rating *</FormLabel>
                        <FormControl>
                          <div className="bg-slate-50 px-4 py-3 rounded-lg border inline-block">
                            <StarRating value={field.value} onChange={field.onChange} />
                          </div>
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="message"
                    render={({ field }) => (
                      <FormItem>
                        <div className="flex items-center justify-between">
                          <FormLabel>Detailed Message *</FormLabel>
                          <span className="text-xs text-muted-foreground">{field.value.length} chars</span>
                        </div>
                        <FormControl>
                          <Textarea
                            placeholder="Please provide specific details about your experience or request..."
                            className="min-h-[140px] resize-y"
                            {...field}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </CardContent>
              </Card>

              <Button
                type="submit"
                size="lg"
                className="w-full text-base font-semibold shadow-lg"
                disabled={createFeedback.isPending}
              >
                {createFeedback.isPending ? "Submitting..." : "Submit Request"}
                {!createFeedback.isPending && <ArrowRight className="w-4 h-4 ml-2" />}
              </Button>
            </form>
          </Form>
        </div>
      </div>
    </div>
  );
}
