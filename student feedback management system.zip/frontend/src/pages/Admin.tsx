import { useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { 
  useListFeedback, 
  useGetFeedbackStats, 
  useUpdateFeedbackStatus, 
  useDeleteFeedback,
  getListFeedbackQueryKey,
  getGetFeedbackStatsQueryKey
} from "@workspace/api-client-react";
import { format } from "date-fns";
import { 
  BarChart, 
  Inbox, 
  Star, 
  TrendingUp, 
  Trash2, 
  CheckCircle2,
  Clock,
  AlertCircle,
  Filter,
  XCircle
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { Progress } from "@/components/ui/progress";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";

const CATEGORY_LABELS: Record<string, string> = {
  faculty_feedback: "Faculty Feedback",
  course_subject_feedback: "Course / Subject Feedback",
  classroom_environment: "Classroom Environment",
  laboratory: "Laboratory",
  examination_assessment: "Examination & Assessment",
  infrastructure_facilities: "Infrastructure & Facilities"
};

export default function Admin() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const [filterCategory, setFilterCategory] = useState<string>("all");
  const [filterStatus, setFilterStatus] = useState<string>("all");

  const { data: stats, isLoading: statsLoading } = useGetFeedbackStats();
  
  const queryParams = {
    ...(filterCategory !== "all" && { category: filterCategory }),
    ...(filterStatus !== "all" && { status: filterStatus })
  };
  
  const { data: feedbackList, isLoading: listLoading } = useListFeedback(queryParams);
  
  const updateStatus = useUpdateFeedbackStatus();
  const deleteFeedback = useDeleteFeedback();

  const handleStatusChange = (id: number, newStatus: "new" | "reviewed" | "resolved") => {
    updateStatus.mutate(
      { id, data: { status: newStatus } },
      {
        onSuccess: () => {
          toast({ title: "Status updated successfully" });
          queryClient.invalidateQueries({ queryKey: getListFeedbackQueryKey() });
          queryClient.invalidateQueries({ queryKey: getGetFeedbackStatsQueryKey() });
        },
        onError: () => {
          toast({ title: "Failed to update status", variant: "destructive" });
        }
      }
    );
  };

  const handleDelete = (id: number) => {
    deleteFeedback.mutate(
      { id },
      {
        onSuccess: () => {
          toast({ title: "Request deleted" });
          queryClient.invalidateQueries({ queryKey: getListFeedbackQueryKey() });
          queryClient.invalidateQueries({ queryKey: getGetFeedbackStatsQueryKey() });
        },
        onError: () => {
          toast({ title: "Failed to delete request", variant: "destructive" });
        }
      }
    );
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'new': return 'bg-blue-50 text-blue-700 border-blue-200 hover:bg-blue-100';
      case 'reviewed': return 'bg-amber-50 text-amber-700 border-amber-200 hover:bg-amber-100';
      case 'resolved': return 'bg-emerald-50 text-emerald-700 border-emerald-200 hover:bg-emerald-100';
      default: return 'bg-slate-50 text-slate-700';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'new': return <AlertCircle className="w-3.5 h-3.5 mr-1.5" />;
      case 'reviewed': return <Clock className="w-3.5 h-3.5 mr-1.5" />;
      case 'resolved': return <CheckCircle2 className="w-3.5 h-3.5 mr-1.5" />;
      default: return null;
    }
  };

  const pendingCount = stats?.byStatus.find(s => s.status === 'new')?.count || 0;
  const maxCategoryCount = stats?.byCategory.reduce((max, c) => Math.max(max, c.count), 0) || 1;

  const hasActiveFilters = filterCategory !== "all" || filterStatus !== "all";

  const clearFilters = () => {
    setFilterCategory("all");
    setFilterStatus("all");
  };

  return (
    <div className="min-h-[calc(100vh-4rem)] bg-slate-50/50 p-4 sm:p-6 lg:p-8">
      <div className="max-w-7xl mx-auto space-y-8">
        
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold tracking-tight text-slate-900">Admin Dashboard</h1>
            <p className="text-slate-500 mt-1">Monitor and manage student feedback across all departments.</p>
          </div>
        </div>

        {/* Stats Section */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 lg:gap-6">
          <Card className="shadow-sm border-slate-200">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-slate-500">Total Requests</CardTitle>
              <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center">
                <Inbox className="w-4 h-4 text-primary" />
              </div>
            </CardHeader>
            <CardContent>
              {statsLoading ? <Skeleton className="h-8 w-20" /> : (
                <div className="text-3xl font-bold text-slate-900">{stats?.total || 0}</div>
              )}
            </CardContent>
          </Card>

          <Card className="shadow-sm border-slate-200">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-slate-500">Average Rating</CardTitle>
              <div className="w-8 h-8 rounded-lg bg-amber-100 flex items-center justify-center">
                <Star className="w-4 h-4 text-amber-600" />
              </div>
            </CardHeader>
            <CardContent>
              {statsLoading ? <Skeleton className="h-8 w-20" /> : (
                <div className="text-3xl font-bold text-slate-900 flex items-baseline gap-1">
                  {stats?.averageRating?.toFixed(1) || "0.0"}
                  <span className="text-sm font-medium text-slate-400">/ 5.0</span>
                </div>
              )}
            </CardContent>
          </Card>

          <Card className="shadow-sm border-slate-200">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-slate-500">Pending / New</CardTitle>
              <div className="w-8 h-8 rounded-lg bg-blue-100 flex items-center justify-center">
                <AlertCircle className="w-4 h-4 text-blue-600" />
              </div>
            </CardHeader>
            <CardContent>
              {statsLoading ? <Skeleton className="h-8 w-20" /> : (
                <div className="text-3xl font-bold text-slate-900">{pendingCount}</div>
              )}
            </CardContent>
          </Card>

          <Card className="shadow-sm border-slate-200">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-slate-500">Recent (7 days)</CardTitle>
              <div className="w-8 h-8 rounded-lg bg-emerald-100 flex items-center justify-center">
                <TrendingUp className="w-4 h-4 text-emerald-600" />
              </div>
            </CardHeader>
            <CardContent>
              {statsLoading ? <Skeleton className="h-8 w-20" /> : (
                <div className="text-3xl font-bold text-slate-900">{stats?.recentCount || 0}</div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Categories Breakdown */}
        <Card className="shadow-sm border-slate-200">
          <CardHeader className="pb-4">
            <CardTitle className="text-lg">Category Breakdown</CardTitle>
          </CardHeader>
          <CardContent>
             {statsLoading ? (
               <div className="space-y-4">
                 {[1, 2, 3].map(i => <Skeleton key={i} className="h-4 w-full" />)}
               </div>
             ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {Object.entries(CATEGORY_LABELS).map(([key, label]) => {
                    const count = stats?.byCategory.find(c => c.category === key)?.count || 0;
                    const percentage = maxCategoryCount > 0 ? (count / maxCategoryCount) * 100 : 0;
                    return (
                      <div key={key} className="space-y-2">
                        <div className="flex items-center justify-between text-sm">
                          <span className="font-medium text-slate-700">{label}</span>
                          <span className="text-slate-500 font-medium bg-slate-100 px-2 py-0.5 rounded-full">{count}</span>
                        </div>
                        <Progress value={percentage} className="h-2 bg-slate-100" />
                      </div>
                    );
                  })}
                </div>
             )}
          </CardContent>
        </Card>

        {/* List Section */}
        <Card className="shadow-sm border-slate-200">
          <CardHeader className="pb-4 border-b">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <CardTitle className="text-lg">Recent Submissions</CardTitle>
              <div className="flex flex-col sm:flex-row items-center gap-3">
                {hasActiveFilters && (
                  <Button variant="ghost" size="sm" onClick={clearFilters} className="text-slate-500 hover:text-slate-900">
                    <XCircle className="w-4 h-4 mr-2" />
                    Clear filters
                  </Button>
                )}
                <div className="flex items-center gap-2">
                  <Filter className="w-4 h-4 text-slate-400" />
                  <Select value={filterCategory} onValueChange={setFilterCategory}>
                    <SelectTrigger className="w-[180px] h-9">
                      <SelectValue placeholder="Category" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Categories</SelectItem>
                      {Object.entries(CATEGORY_LABELS).map(([key, label]) => (
                        <SelectItem key={key} value={key}>{label}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <Select value={filterStatus} onValueChange={setFilterStatus}>
                    <SelectTrigger className="w-[140px] h-9">
                      <SelectValue placeholder="Status" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Status</SelectItem>
                      <SelectItem value="new">New</SelectItem>
                      <SelectItem value="reviewed">Reviewed</SelectItem>
                      <SelectItem value="resolved">Resolved</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </div>
          </CardHeader>
          <CardContent className="p-0">
            {listLoading ? (
              <div className="space-y-0 divide-y">
                {[1, 2, 3, 4, 5].map(i => (
                  <div key={i} className="p-4 flex gap-4">
                    <Skeleton className="h-10 w-10 rounded-full" />
                    <div className="space-y-2 flex-1">
                      <Skeleton className="h-4 w-1/4" />
                      <Skeleton className="h-4 w-full" />
                    </div>
                  </div>
                ))}
              </div>
            ) : !feedbackList?.length ? (
              <div className="flex flex-col items-center justify-center py-20 px-4 text-center">
                <div className="w-16 h-16 bg-slate-100 rounded-full flex items-center justify-center mb-4">
                  <Inbox className="w-8 h-8 text-slate-400" />
                </div>
                <h3 className="text-lg font-semibold text-slate-900">No submissions found</h3>
                <p className="text-slate-500 mt-1 max-w-sm">
                  {hasActiveFilters 
                    ? "Try adjusting your filters to see more results." 
                    : "When students submit feedback or requests, they will appear here."}
                </p>
                {hasActiveFilters && (
                  <Button variant="outline" className="mt-4" onClick={clearFilters}>
                    Clear all filters
                  </Button>
                )}
              </div>
            ) : (
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader className="bg-slate-50">
                    <TableRow>
                      <TableHead className="w-[120px]">Date</TableHead>
                      <TableHead>Student</TableHead>
                      <TableHead>Department</TableHead>
                      <TableHead>Category / Reason</TableHead>
                      <TableHead className="w-[100px]">Rating</TableHead>
                      <TableHead className="max-w-[250px]">Message</TableHead>
                      <TableHead className="w-[160px]">Status</TableHead>
                      <TableHead className="text-right w-[80px]">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {feedbackList.map((item) => (
                      <TableRow key={item.id} className="hover:bg-slate-50/50">
                        <TableCell className="text-sm font-medium text-slate-600 whitespace-nowrap">
                          {format(new Date(item.createdAt), "MMM d, yyyy")}
                        </TableCell>
                        <TableCell>
                          <div className="font-medium text-slate-900">{item.name}</div>
                          <div className="text-xs text-slate-500 mt-0.5">{item.studentId}</div>
                        </TableCell>
                        <TableCell>
                          <div className="text-sm text-slate-900">{item.department}</div>
                          <div className="text-xs text-slate-500 mt-0.5">{item.semester}</div>
                        </TableCell>
                        <TableCell>
                          <Badge variant="secondary" className="bg-slate-100 text-slate-700 hover:bg-slate-200 mb-1 border-slate-200">
                            {CATEGORY_LABELS[item.category] || item.category}
                          </Badge>
                          <div className="text-xs text-slate-500">{item.subReason}</div>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-1 bg-amber-50 px-2 py-1 rounded-md w-max border border-amber-100">
                            <Star className="w-3.5 h-3.5 text-amber-500" fill="currentColor" />
                            <span className="font-semibold text-amber-700 text-sm">{item.rating}</span>
                          </div>
                        </TableCell>
                        <TableCell className="max-w-[250px]">
                          <Tooltip>
                            <TooltipTrigger asChild>
                              <div className="text-sm text-slate-600 truncate cursor-help">
                                {item.message}
                              </div>
                            </TooltipTrigger>
                            <TooltipContent side="top" className="max-w-[400px] p-4 text-sm bg-slate-900 text-slate-50">
                              {item.message}
                            </TooltipContent>
                          </Tooltip>
                        </TableCell>
                        <TableCell>
                          <Select 
                            defaultValue={item.status} 
                            onValueChange={(val: any) => handleStatusChange(item.id, val)}
                          >
                            <SelectTrigger className={`h-8 font-medium text-xs border ${getStatusColor(item.status)}`}>
                              <div className="flex items-center capitalize">
                                {getStatusIcon(item.status)}
                                <SelectValue />
                              </div>
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="new">New</SelectItem>
                              <SelectItem value="reviewed">Reviewed</SelectItem>
                              <SelectItem value="resolved">Resolved</SelectItem>
                            </SelectContent>
                          </Select>
                        </TableCell>
                        <TableCell className="text-right">
                          <AlertDialog>
                            <AlertDialogTrigger asChild>
                              <Button variant="ghost" size="icon" className="text-slate-400 hover:text-red-600 hover:bg-red-50">
                                <Trash2 className="w-4 h-4" />
                              </Button>
                            </AlertDialogTrigger>
                            <AlertDialogContent>
                              <AlertDialogHeader>
                                <AlertDialogTitle>Delete Submission</AlertDialogTitle>
                                <AlertDialogDescription>
                                  Are you sure you want to delete this submission from {item.name}? This action cannot be undone.
                                </AlertDialogDescription>
                              </AlertDialogHeader>
                              <AlertDialogFooter>
                                <AlertDialogCancel>Cancel</AlertDialogCancel>
                                <AlertDialogAction 
                                  onClick={() => handleDelete(item.id)}
                                  className="bg-red-600 text-white hover:bg-red-700"
                                >
                                  Delete
                                </AlertDialogAction>
                              </AlertDialogFooter>
                            </AlertDialogContent>
                          </AlertDialog>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
